<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2022-02-24 15:51:40
 * @LastEditTime: 2022-02-26 11:03:23
 * @LastEditors: Please set LastEditors
 -->
<%@page import="com.landray.kmss.sys.profile.util.LoginTemplateUtil"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.awt.Image,javax.imageio.ImageIO"%>
<%@ page import="java.util.Random,java.io.File,java.io.FilenameFilter"%>
<%@ page import="java.util.Locale,java.util.Date"%>
<%@ page import="com.landray.kmss.web.Globals"%>
<%@ page import="com.landray.kmss.util.ResourceUtil,com.landray.kmss.util.DateUtil"%>
<%@ include file="/sys/ui/jsp/common.jsp"%>
<c:import url="./login_config.jsp" charEncoding="UTF-8">
</c:import>
<!-- id 变量需要和config.ini id -->
<c:set var="templatePath" value="${LUI_ContextPath}/resource/login/login_26_festival_spring/" />

<template:include ref="default.login">
    <template:replace name="head">
        <!-- 通栏登录-V15版本 -->
        <link href="${ templatePath }font/iconfont.css?s_cache=${LUI_Cache}202001153" rel="stylesheet" type="text/css" />
        <link type="text/css" rel="stylesheet" href="${templatePath}css/login.css?s_cache=${LUI_Cache}202001153" />
        <script src="${templatePath}js/jquery.js?s_cache=${LUI_Cache}202001153"></script>
        <script src="${templatePath}js/jquery.fullscreenr.js?s_cache=${LUI_Cache}202001153"></script>
        <script src="${templatePath}js/custom.js??s_cache=${LUI_Cache}202001153"></script>
        <!-- <title>	${lfn:loginLangMsg('custom_header') }</title> -->
        <style>
            body {
                margin: 0;
                background-color: #ad1e03!important;
            }
        </style>
    </template:replace>
    <template:replace name="body">
        <script>
            var templatePath = '${templatePath}';
        </script>
        <!-- 背景图片 Starts -->
        <div class="login-background-img login-background-img-fullscreen">
            <img id="login-bgImg" src="${ templatePath }login_bg/thumb-1.jpg" data-thumb="${ templatePath }login_bg/thumb-2.jpg" data-src="${ templatePath }login_bg/bg-login.jpg" alt=""/>
        </div>
    
        <script type="text/javascript">
            // 背景图片截取
            jQuery.fn.fullscreenr({ width: 1920, height: 936, bgID: '#login-bgImg' });
        </script>
        <!-- 背景图片 Ends -->

        <!-- LOGO路径 start-->
        <div class="login_header logo_header">
            <div class="logo">
                <img src="${templatePath}${config.custom_logo}" />
            </div>
            <div class="login_top_bar">
                <ul>
                    <c:forEach items="${config.single_random_head_links }" var="link" varStatus="status">
                        <li>
                            <a target="_blank" href="${ link.single_random_head_link_href}">${lfn:loginArrayLangMsg('single_random_head_links',status.index,'single_random_head_link') }</a>
                        </li>
                    </c:forEach>
                </ul>
            </div>
            
        </div>
        <!-- LOGO路径 end-->
        <div class="login_content_v15">
        <!-- 登录框 开始 -->
        <div class="login_iframe">
            <div class="login_iframe_box">
                <div class="login_iframe_wrap">
                    <!-- 表格内容 start -->
                    <%@ include file="./form.jsp"%>
                    <!-- 表格内容 end -->
                </div>
                <div class="login_footer">
                    <%
                        // 版权信息的年份根据服务器时间自动获取
                        String s_year = DateUtil.convertDateToString(new Date(), "yyyy");
                        String footerInfo = ResourceUtil.getString("login.page.footer.info", null, null, s_year);
                    %>
                    <p>${lfn:loginLangMsg('custom_footInfo') }</p>
                </div>
            </div>
        </div>
        <!-- 登录框 结束 -->
        </div>

        <div class="hiddenDiv"></div>
        <script>
             seajs.use(['lui/jquery'], function($) {
                 $(document).ready(function () {
                     // 密码可见不可见
                     var showPwd = false;
                     $(".icon_pwd").on("click", function () {
                         var $this = $(this);
                         var $_input_pwd = $this.siblings(".lui_login_input_password");
                         var $_input_pwd_parent = $this.parent(".lui_login_input_div");
                         $this.css("background-color","transparent");
                         if (showPwd) {
                             $_input_pwd.attr("type", "password");
                             $_input_pwd_parent.removeClass("showPwd");
                         } else {
                             $_input_pwd.attr("type", "text");
                             $_input_pwd_parent.addClass("showPwd");
                         }
                         showPwd = !showPwd;
                     });
                 })
             });
         </script>
    </template:replace>
</template:include>
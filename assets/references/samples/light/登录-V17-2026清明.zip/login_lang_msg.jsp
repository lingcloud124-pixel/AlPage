<%@ page import="net.sf.json.JSONArray"%>
<%@ page import="net.sf.json.JSONObject"%>
<%@ page import="com.landray.kmss.framework.service.plugin.Plugin"%>
<%@ page import="javax.servlet.http.HttpServletRequest"%>
<%@ page import="com.landray.kmss.util.ResourceUtil"%>
<%@ page import="com.landray.kmss.util.StringUtil"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%-- 定义多语言 --%>
<%
	JSONObject loginConfig = new JSONObject();

	//登录系统
	loginConfig.put("custom_header_CN", "登录系统");
	loginConfig.put("custom_header_HK", "歡迎登錄");
	loginConfig.put("custom_header_JP", "ようこそ");
	loginConfig.put("custom_header_US", "Welcome Login");

	//用户名
	loginConfig.put("custom_username_CN", "用户名");
	loginConfig.put("custom_username_HK", "用戶名");
	loginConfig.put("custom_username_JP", "ユーザー名");
	loginConfig.put("custom_username_US", "Username");

	//密码
	loginConfig.put("custom_password_CN", "密码");
	loginConfig.put("custom_password_HK", "密碼");
	loginConfig.put("custom_password_JP", "パスワード");
	loginConfig.put("custom_password_US", "Password");

	//验证码
	loginConfig.put("custom_code_CN", "验证码");
	loginConfig.put("custom_code_HK", "驗證碼");
	loginConfig.put("custom_code_JP", "検証コード");
	loginConfig.put("custom_code_US", "Verification code");
	
    request.setAttribute("config", loginConfig);
%>

<%-- 定义多语言处理方法 --%>
<%!
	private static String officialLangCountry = null;
	public static String getOfficialLang() {
		if (StringUtil.isNotNull(officialLangCountry)) {
			return officialLangCountry;
		}
		String officialLang = ResourceUtil
				.getKmssConfigString("kmss.lang.official");
		if (StringUtil.isNull(officialLang)) {
			return null;
		}
		officialLangCountry = officialLang;
		if (officialLang.contains("|")) {
			officialLangCountry = officialLang
					.substring(officialLang.indexOf("\\|") + 1);
		}
		if (officialLangCountry.contains("-")) {
			officialLangCountry = officialLangCountry
					.substring(officialLangCountry.indexOf("-") + 1);
		}
		return officialLangCountry;
	}

	public static String getLangMsg(String key) {
		String value = "";
		try {
			HttpServletRequest request = Plugin.currentRequest();
			Object obj = request.getAttribute("config");
			if (obj == null) {
				return value;
			}
			JSONObject config = (JSONObject) obj;
			String country = ResourceUtil.getLocaleByUser().getCountry();
			String officialLang = getOfficialLang();
			if (StringUtil.isNull(officialLang)) {
				officialLang = "CN";
			}
			value = config.get(key + "_" + country) == null
					? config.getString(key + "_" + officialLang)
					: config.getString(key + "_" + country);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		return value;
	}
%>
<%-- {"custom_logo":"logo/logo.png","custom_footInfo_CN":"Copyright © 2001-2021 蓝凌软件 版权所有","custom_footInfo_HK":"Copyright © 2001-2021 藍凌軟件 版權所有","custom_footInfo_JP":"Copyright © 2001-2021 靑ソフト 著作権所有","custom_footInfo_US":"Copyright © 2001-2021 Landray software","custom_header_CN" : "登录系统","custom_header_HK":"歡迎登錄","custom_header_JP": "ようこそ","custom_header_US": "Welcome Login","custom_forgot_password_CN":"忘记密码","custom_forgot_password_HK": "忘記密碼","custom_forgot_password_JP":"パスワードを忘れます","custom_forgot_password_US":"Forget password"} --%>
<%@page import="java.util.Date"%>
<%@page import="com.landray.kmss.util.DateUtil"%>
<%@page import="net.sf.json.JSONObject"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
	//版权信息的年份根据服务器时间自动获取
	String __year = DateUtil.convertDateToString(new Date(), "yyyy");

	JSONObject loginConfig = new JSONObject();
	loginConfig.put("custom_logo", "logo/logo.png");
	loginConfig.put("custom_footInfo_CN", "Copyright © 2001-"+__year+" 蓝凌软件 版权所有");
	loginConfig.put("custom_footInfo_HK", "Copyright © 2001-"+__year+" 藍凌軟件 版權所有");
	loginConfig.put("custom_footInfo_JP", "Copyright © 2001-"+__year+" 靑ソフト 著作権所有");
	loginConfig.put("custom_footInfo_US", "Copyright © 2001-"+__year+" Landray software");

	//登录系统
	loginConfig.put("custom_header_CN", "登录系统");
	loginConfig.put("custom_header_HK", "歡迎登錄");
	loginConfig.put("custom_header_JP", "ようこそ");
	loginConfig.put("custom_header_US", "Welcome Login");

	//忘记密码
	loginConfig.put("custom_forgot_password_CN", "忘记密码");
	loginConfig.put("custom_forgot_password_HK", "忘記密碼");
	loginConfig.put("custom_forgot_password_JP", "パスワードを忘れます");
	loginConfig.put("custom_forgot_password_US", "Forget password");
	//
	request.setAttribute("config", loginConfig);
%>
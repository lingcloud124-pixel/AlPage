import React from 'react';
import { runApp, IConfig } from '@elements-toolkit/mkworks-cli'
import Login from '../index'
const pkg = require('../../package.json')

function App(props) {
 
  return (
    <Login {...props}/>
  )
}

const config: IConfig = {
  loginLocation: {
    controlType: 'radio',
    default: 'left',
    value: ['left', 'right'],
    label: '位置'
  },
  loginTitle: {
    default: '欢迎登录',
    controlType: 'string',
    label: '标题'
  },
  logoURL: {
    controlType: 'string',
    default: '@user-login/test-login-og4on/static/logo.png',
    label: 'logo'
  },
  logoSubTitle: {
    controlType: 'string',
    default: '知识管理与协同领导品牌',
    label: '宣传语'
  },
  copyRight: {
    controlType: 'textarea',
    default: '©2001-2021 深圳市蓝凌软件股份有限公司 版权所有',
    label: '版权'
  },
  bgSize: {
    controlType: 'radio',
    default: 'cover',
    value: ['contain', 'cover'],
    label: '背景尺寸'
  },
  loginBtnText: {
    controlType: 'string',
    default: '登录',
    label: '登录按钮名称'
  },
  backgroundURL: {
    controlType: 'string',
    default: '@user-login/test-login-og4on/static/background.png',
    label: '背景图片'
  },
  loginWithDingTalk: {
    controlType: 'checkbox',
    default: false,
    label: '钉钉'
  },
  showDownloadBtn: {
    controlType: 'checkbox',
    default: false,
    label: 'kk下载按钮'
  },
  loginWithKK: {
    controlType: 'checkbox',
    default: false,
    label: 'KK'
  },
  moreLan: {
    controlType: 'checkbox',
    default: true,
    label: '多语言'
  }
}

runApp(App, config, pkg)

const langs = {
  'zh-cn': {
    login: {
      loginText:'登录',
      kkDownload:'KK客户端下载',
      username:'用户名',
      password:'请输入密码',
      vCode:'请输入验证码',
      rememberPassword:'记住密码',
      forgotPassword:'忘记密码',
      loginErrorText:'登录账号或密码错误，请重新输入',
      vCodeErrorText:'验证码错误',
      loginBtn:'登录',
      loginAccount: '账号登录',
      qrcodeForDingDing: '使用钉钉客户端扫码登录'
    }
  },
  'en-us': {
    login: {
      loginText:'Login',
      kkDownload:'Download KK client',
      username:'Username',
      password:'Password',
      vCode:'Please enter the characters you see',
      rememberPassword:'Remember password',
      forgotPassword:'Forgot',
      loginErrorText:'Invalid username/password',
      vCodeErrorText:'Verification code wrong',
      loginBtn:'Login',
      loginAccount: 'Account login',
      qrcodeForDingDing: 'Log in using the dingding client scan code'
    }
  }
}

export default langs

import React, { PureComponent } from 'react'
import { prefixCls } from './constants'
import { IProps } from './props'
import './style.scss'

export default class Footer extends PureComponent<IProps> {
  static defaultProps = {
    copyRight: `&copy;2001-${new Date().getFullYear()} 深圳市蓝凌软件股份有限公司 版权所有`
  }

  render () {
    const { copyRight } = this.props

    return (
      <div className={`${prefixCls}-copyright-box`}>
        {
          (/&[\w]+;/.test(mk.getI18nMessage(copyRight))) ? (
            <p className={`${prefixCls}-copyright`}
              dangerouslySetInnerHTML={{ __html: mk.getI18nMessage(copyRight) }} />
          ) : (
            <p className={`${prefixCls}-copyright`}>{mk.getI18nMessage(copyRight)}</p>
          )
        }
      </div>
    )
  }
}
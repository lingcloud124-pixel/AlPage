import React, { Fragment } from 'react'
import Input from '@elem/input'
import Button, { EBtnType } from '@elem/button'
import Checkbox from '@elem/checkbox'
import { FormFactory, IFormComponentProps } from '@elem/form'
import BaseLoginForm, {
  ILoginData,
  ILoginResponse,
  gotoForgetPassword,
  getSessionToken,
  gotoUpdatePassword,
  isCode,
  // 新增：引入验证码相关组件/方法
  CodeCanvas,
  isShowForgetPass
} from '@elem/login-base'
import IframeQRC from '@elem/ding-qr-code'
import Icon from '@elem/icon'
import { prefixCls } from './constants'
import loginlangs from './langs'
import { IProps } from './props'
// 新增：引入防抖函数
import debounce from 'lodash/debounce'

interface IState {
  // 登录按钮是否可用
  // isActiveSubmit: boolean
  // 是否需要验证码
  isVcode: boolean
  // 账号登录方式
  loginMode: string
  // 错误提示
  showError: boolean
  // 错误信息
  errorText: string
  // 二维码地址
  qrcode: string
  //表单值
  values: ILoginData
  // 动态表单
  form?: any
  // 表单提交中
  isSubmiting: boolean
  /** 状态 */
  gotoPwd?: any
  // 新增：验证码相关状态
  /** 是否展示忘记密码 */
  showForgetPass?: boolean
  /** 验证码 */
  defaultCode?: string
  // 新增：登录按钮激活状态（验证码需要）
  isActiveSubmit: boolean
}

export default class Login extends BaseLoginForm<IProps, IState> {
  static defaultProps = {
    logoURL: '@user-login/a4-ada21/static/logo.png',
    loginTitle: '登录',
    loginBtnText: '登录',
    forgetPassword: true,
    kkDownload: false
  }

  formRef: React.ReactElement<IFormComponentProps>
  lang = mk.getI18nMessage(loginlangs, 'login')

  constructor (props: IProps) {
    super(props)
    try {
      isCode()
    } catch { }
    this.state = {
      // 是否激活登录按钮
      isActiveSubmit: false, // 新增：初始化登录按钮激活状态
      // 是否展示验证码
      isVcode: false,
      // 账号登录方式
      loginMode: 'account',
      // 错误提示
      showError: false,
      // 错误信息
      errorText: '',
      // 二维码地址
      qrcode: mk.getResourcePath('@login/simple/static/qrcode.png'),
      // 表单值
      values: { username: '', password: '' },
      isSubmiting: false,
      // 新增：验证码相关初始化
      showForgetPass: false,
      defaultCode: undefined
    }
  }

  // 新增：组件卸载时移除事件监听
  componentWillUnmount() {
    mk.off('MK_LOGIN_PAGE_CHANGE_LOCAL', this.forceUpdateLogin)
  }

  componentDidMount () {
    // 新增：添加语言变更监听
    mk.on('MK_LOGIN_PAGE_CHANGE_LOCAL', this.forceUpdateLogin)
    // 新增：检查是否展示忘记密码
    this.checkShowforgetPassword()
    // 新增：初始化验证码
    this.initSystem()
    
    this.initForm()
  }

  componentDidUpdate (){
    const nextLang = mk.getI18nMessage(loginlangs, 'login')
    if (this.lang !== nextLang){
      this.lang = nextLang
      this.initForm()
    }
  }

  // 新增：强制更新登录组件
  forceUpdateLogin = () => {
    this.forceUpdate()
  }

  // 新增：检测初始化状态，加载验证码
  initSystem = async () => {
    // 设置0次之后出现验证码，需要在进入页面就展示验证码
    const newCode = await this.getVcode()
    if(newCode) {
      this.setState({
        defaultCode: newCode,
        isVcode: true
      }, () => {
        if (newCode) {
          this.initForm()
        }
      })
    }
  }

  // 新增：获取通用配置--用于判断是否展示忘记密码字段
  checkShowforgetPassword = async () => {
    const showForgetPass = await isShowForgetPass()
    this.setState({ showForgetPass })
  }

  // 新增：用户名防抖change
  handleChangeName = debounce(async (e) => {
    if (e.target?.value) {
      const newCode = await this.getVcode(e.target.value)
      const hasVcode = newCode ? true : false
      const lastHasVcode = this.state.isVcode

      this.setState({
        errorText: '',
        defaultCode: newCode,
        isVcode: hasVcode
      }, () => {
        newCode && this.initForm()
        hasVcode !== lastHasVcode && this.initForm()
      })
    }
  }, 600)

  initForm = () => {
    const loginLang = mk.getI18nMessage(loginlangs, 'login')

    const formItem = [
      {
        id: 'username',
        cmpt: (
          <Input
            placeholder={loginLang.username}
            className="login-fullscreen-input font-base"
            type="text"
            // 新增：验证码相关处理
            readOnly={true}
            onFocus={() => {
              document.getElementById('username')!.removeAttribute('readonly')
            }}
            onBlur={async (e) => {
              if(e.target.value && this.state.defaultCode === undefined) {
                const newCode = await this.getVcode(e.target.value)
                this.setState({
                  errorText: '',
                  defaultCode: newCode,
                  isVcode: newCode ? true : false
                }, () => {
                  newCode && this.initForm()
                })
              }
            }}
            onChange={this.handleChangeName}
            // 原有逻辑保留
            onKeyDown={(e) => {
              this.enterOn(e, this.callBackValue)
            }}
            autoComplete="k9jismuc"
            autoFocus
          />
        ),
        formItemOptions: {}
      },
      {
        id: 'password',
        cmpt: (
          <Input
            placeholder={loginLang.password}
            className="login-fullscreen-input font-base"
            type="password"
            onKeyDown={(e) => {
              this.enterOn(e, this.callBackValue)
            }}
          />
        ),
        formItemOptions: {}
      }
    ]
    // 用户名、密码、验证码表单项
    const formItemWithVcode = [
      ...formItem,
      {
        // 新增：验证码表单项（替换原有简单验证码）
        id: 'validationCode',
        cmpt: (
          <Input
            placeholder={loginLang.vCode}
            className="login-fullscreen-input login-fullscreen-vcode-box"
            type="text"
            autoComplete="off"
            onKeyDown={(e) => {
              if (e.keyCode === 13) {
                this.callBackValue()
              }
            }}
            suffix={<span className={`${prefixCls}-vcode text-info`} onClick={async () => {
              const newCode = await this.getVcode(this.state?.values?.username)
              this.setState({
                defaultCode: newCode
              }, () => { this.initForm() })
            }}>
              <span className={`${prefixCls}-vcode-canvas`}>
                <CodeCanvas theme={'light'} code={this.state.defaultCode} />
              </span>
              <Icon name="iconCommon_surface_16_change" normalize />
            </span>}
          />
        ),
        formItemOptions: {},
      }
      // 原有验证码逻辑注释掉
      // {
      //   id: 'vcode',
      //   cmpt: (
      //     <Input
      //       placeholder={loginLang.vCode}
      //       className="login-fullscreen-input login-fullscreen-vcode-box"
      //       type="text"
      //       onKeyDown={(e) => {
      //         this.enterOn(e, this.callBackValue)
      //       }}
      //       suffix={
      //         <img
      //           className={`${prefixCls}-vcode`}
      //           src="https://sp4test.landray.com.cn/data/sys-auth/verificationCode/getCode?hash=1769065725952"
      //         />
      //       }
      //     />
      //   ),
      //   formItemOptions: {}
      // }
    ]

    const WrappedForm = FormFactory({
      forms: [
        {
          name: 'form',
          items: this.state.isVcode ? formItemWithVcode : formItem
        }
      ]
    })

    this.setState({
      form: WrappedForm
    })
  }

  getValue () {
    const values = this.formRef.props.form.getFieldsValue() as ILoginData
    return values
  }

  handlePwd = async () => {
    await getSessionToken(this.getValue()).then(res => {
      this.setState({
        gotoPwd: res
      })
    })
  }

  // 改造：点击登录按钮逻辑，集成验证码处理
  onClick = async () => {
    const values = this.getValue()
    
    // 新增：验证码逻辑处理
    if (values.username && this.state.defaultCode === undefined) {
      const newCode = await this.getVcode(values.username)
      this.setState({
        values: values,
        defaultCode: newCode,
        isVcode: newCode ? true : false
      }, () => {
        if (newCode) {
          this.initForm()
        } else {
          // 原有逻辑保留
          this.submit()
          this.handlePwd()
        }
      })
    } else {
      // 原有逻辑保留
      this.setState({ values: values }, () => {
        this.submit()
        this.handlePwd()
      })
    }
  }

  // 改造：表单值变更逻辑，添加验证码校验
  onChange = (props, changedValues, allValues) => {
    const { username, password, validationCode } = allValues || ({} as any)
    const { isVcode } = this.state
    
    // 新增：登录按钮激活状态判断
    this.setState({
      values: allValues,
      isActiveSubmit: !isVcode ? (!!username && !!password) : (!!username && !!password && !!validationCode)
    })
  }

  // 改造：回调事件，集成验证码处理
  callBackValue = (newCode?: string) => {
    const val = this.getValue()
    this.setState({
      values: val,
      defaultCode: newCode,
      isVcode: newCode ? true : false
    },() => {
      // 新增：验证码逻辑
      if (newCode) {
        this.initForm()
      } else {
        // 原有逻辑保留
        this.handlePwd()
        this.submit()
      }
    })
  }

  async beforeSubmit (): Promise<ILoginResponse> {
    const res = await super.beforeSubmit()
    this.setState({
      isSubmiting: true
    })
    return res
  }

  // 改造：提交后逻辑，添加验证码刷新
  afterSubmit (response: ILoginResponse) {
    this.setState({
      isSubmiting: false,
      showError: !response.success,
      errorText: response.msg
    }, async () => {
      if(!this.state.showError) {
        setTimeout(() => {
          mk.emit('plugin-password-modal',{type: 'password'})  
        }, 2000)
      }
      
      // 新增：登录失败时刷新验证码
      if (!response.success) {
        const newCode = await this.getVcode(this.state.values.username)
        this.setState({
          defaultCode: newCode,
          isVcode: newCode ? true : false
        }, () => {
          if (newCode) {
            this.initForm()
          }
        })
      }
    })
    return response.success
  }

  switchLoginMode (mode: string) {
    mode && this.setState({
      loginMode: mode
    })
  }

  renderAccountPart () {
    const loginLang = mk.getI18nMessage(loginlangs, 'login')

    const { showError, errorText, form: WrappedForm, isActiveSubmit, showForgetPass } = this.state
    const {
      loginWithDingTalk,
      loginWithKK,
      loginTitle,
      loginBtnText,
      forgetPass,
      showDownloadBtn,
    } = this.props
   
    return (
      WrappedForm && (
        <Fragment>
          <div className={`${prefixCls}-header`}>
            <span className={`${prefixCls}-login-text text-theme font-lg`}>
              {mk.getI18nMessage(loginTitle)}
            </span>
          </div>
          <div className={`${prefixCls}-form`}>
            <WrappedForm
              values={this.state.values}
              onValuesChange={this.onChange}
              wrappedComponentRef={formRef => {
                this.formRef = formRef
              }}
            />
          </div>
          <div className={`${prefixCls}-funs`}>
            <a
              href="http://kk5.landray.com.cn:8000/serverj"
              className={`${prefixCls}-kk-download text-info font-base`}
            >
              {showDownloadBtn && loginLang.kkDownload}
            </a>
            <span>
              <Checkbox style={{ display: 'none' }}>
                <span className={`${prefixCls}-password-remmber-text`}>
                  {loginLang.rememberPassword}
                </span>
              </Checkbox>
            </span>
            <span
              className={`${prefixCls}-forget-password font-base`}
              onClick={() => {
                gotoForgetPassword()
              }}
            >
              {/* 新增：结合验证码逻辑的忘记密码展示判断 */}
              {forgetPass && showForgetPass && loginLang.forgotPassword}
            </span>
          </div>
          {showError && (
            <p className={`${prefixCls}-error-text text-error font-sm`}>
              {errorText.indexOf('密码已失效') > -1
                ? (typeof this.state.gotoPwd === 'object' ? 
                  <span>密码已失效,请
                    <span 
                      style={{color: '#f8d08a',cursor: 'pointer'}} 
                      onClick={() => {
                        mk.userStore.set({
                          key: 'PASSWORD_CHANGE_SESSION',
                          value: this.state.gotoPwd.sessionToken || ''
                        })
                        gotoUpdatePassword()
                      }}
                    > 重新设置 </span>
                  密码</span> : 
                  <span>{this.state.gotoPwd}</span>)
                : (
                  errorText.indexOf('基于安全考虑') > -1
                    ? (typeof this.state.gotoPwd === 'object' ?
                      <span>基于安全考虑,首次登陆请先
                        <span
                          style={{color: '#f8d08a',cursor: 'pointer'}}
                          onClick={() => {
                            mk.userStore.set({
                              key: 'PASSWORD_CHANGE_SESSION',
                              value: this.state.gotoPwd.sessionToken || ''
                            })
                            gotoUpdatePassword()
                          }}
                        > 修改密码 </span>
                      </span> :
                      <span>{this.state.gotoPwd}</span>
                    )
                    : errorText
                )
              } 
            </p>
          )}
          <div
            className={['assist-submit']
              .concat(isActiveSubmit ? ['assist-submit-active'] : [])
              .join(' ')}
          >
            <Button
              className={`${prefixCls}-login-btn font-md`}
              // 新增：验证码逻辑的按钮禁用判断
              disabled={!isActiveSubmit}
              loading={this.state.isSubmiting}
              onClick={this.onClick}
              type={EBtnType.primary}
            >
              {mk.getI18nMessage(loginBtnText || '')}
            </Button>
          </div>
          {(loginWithDingTalk || loginWithKK) && (
            <div className={`${prefixCls}-icon-wrapper`}>
              {loginWithDingTalk && (
                <a
                  className={`${prefixCls}-icon-wrapper-item hover-bd-theme`}
                  onClick={this.switchLoginMode.bind(this, 'dingding')}
                >
                  <Icon
                    name="dingding"
                    type="vector"
                    className={`${prefixCls}-icon`}
                  />
                </a>
              )}
              {loginWithKK && (
                <a
                  className={`${prefixCls}-icon-wrapper-item hover-bd-theme`}
                  onClick={this.switchLoginMode.bind(this, 'kk')}
                >
                  <Icon
                    name="kk"
                    type="vector"
                    className={`${prefixCls}-icon`}
                  />
                </a>
              )}
            </div>
          )}
        </Fragment>
      )
    )
  }

  renderQRScanPart () {
    const loginLang = mk.getI18nMessage(loginlangs, 'login')

    return (
      <div className={`${prefixCls}-qrcode-content`}>
        <IframeQRC />
        <a
          className={`${prefixCls}-transfer-btn font-base`}
          onClick={this.switchLoginMode.bind(this, 'account')}
        >
          {loginLang.loginAccount}
        </a>
      </div>
    )
  }

  render () {
    const { loginMode } = this.state
    const { logoURL } = this.props
    return (
      <div
        className={`${prefixCls}-login-module text-info`}>
        <div className={`${prefixCls}-login-wrap`}>
          <div className={`${prefixCls}-logo-box`}>
            <img
              src={mk.getResourcePath(logoURL)}
              className={`${prefixCls}-logo`}
            />
          </div>
          {loginMode === 'account' ? (
            this.renderAccountPart()
          ) : (
            this.renderQRScanPart()
          )}
          <div className={`${prefixCls}-auth`} />
        </div>
      </div>
    )
  }
}
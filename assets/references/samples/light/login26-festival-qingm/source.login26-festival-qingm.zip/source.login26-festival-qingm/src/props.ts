export type IAllLangs = Array<{
  /** 语言的显示名称 */
  name: string
  /** 语言内部值 */
  val: string
}>

export enum EloginLocationOption {
  /** 左 */
  'left' = 'left',
  /** 右 */
  'right' = 'right'
}

export const enum EBgImageSize {
  /** 等比拉伸 */
  'cover' = 'cover',
  /** 显示原图 */
  'contain' = 'contain'
}
export interface IGroupProps {
  /**
   * 基本信息
   * @tab loginPage
   */
  baseGroup: IGroup
  /**
   * 背景
   * @tab background
   */
  backgroundGroup: IGroup
  /**
   * 按钮
   * @tab loginPage
   */
  butGroup: IGroup
  /**
   * 内容
   * @tab loginPage
   */
  contentGroup: IGroup
}

export interface IProps {
  /**
   * 位置
   * @group baseGroup
   * @default right
   */
  loginLocation?: EloginLocationOption
  /**
   * 标题
   * @group baseGroup
   * @render locale
   * @default 欢迎登录
   */
  loginTitle?: string
  /**
   * 标题
   * @group baseGroup
   * @render locale
   * @default 测试
   */
  loginTitleDesc?: string
  /** 多语言
   * @private
   */
  allLangs?: IAllLangs
  /** 切换语言
   * @private
   */
  onChange?: (val: string) => void

  /**
   * logo
   * @group backgroundGroup
   * @render image
   * @default &#64;user-login/login26-festival-qingm/static/logo.png
   * @help 尺寸：建议不超过210px*60px
   */
  logoURL?: string
  /**
   * 版权
   * @group backgroundGroup
   * @render locale
   * @renderType textarea
   * @default &copy;2001-${new Date().getFullYear()}$ 深圳市蓝凌软件股份有限公司 版权所有
   */
  copyRight?: string
  /**
   * 背景
   * @group backgroundGroup
   * @render image
   * @default &#64;user-login/login26-festival-qingm/static/background.png
   * @help 尺寸：建议1920px*1080px；仅支持jpg，jpeg，gif，png且小于<span style="color: #F25643">5MB</span>
   */
  backgroundURL?: string

  /**
   * 图片显示
   * @group backgroundGroup
   * @default cover
   */
  bgSize?: EBgImageSize
  /**
   * 名称
   * @group butGroup
   * @render locale
   * @default 登录
   */
  loginBtnText?: string

  /**
   * 钉钉
   * @group contentGroup
   * @default false
   */
  loginWithDingTalk?: boolean
  /**
   * KK
   * @group contentGroup
   * @hidden
   * @default false
   */
  loginWithKK?: boolean
  /**
   * Kk客户端下载
   * @group contentGroup
   * @hidden
   * @default false
   */
  showDownloadBtn?: boolean
  /**
   * 忘记密码
   * @group contentGroup
   * @default true
   */
  forgetPass?: boolean
  /**
   * 多语言
   * @group contentGroup
   * @default true
   */
  moreLan?: boolean
}
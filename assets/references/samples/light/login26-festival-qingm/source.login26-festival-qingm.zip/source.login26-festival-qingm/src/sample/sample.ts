const defaultRenderConfig = {
  loginLocation: 'right',
  loginTitle: '欢迎登录',
  loginBtnText: '登陆',
  loginWithKK: false,
  loginWithDing: false,
  showDownloadBtn: false,
  forgetPass: true,
  moreLan: true,
  logoURL: '@user-login/login-test-rcj77/static/logo.png',
  copyRight: '©2001-2019 深圳市蓝凌软件股份有限公司 版权所有',
  backgroundURL: '@user-login/login-test-rcj77/static/background.png',
  bgSize: 'cover'
}
const sample= {
  defaultRenderConfig
}

export default sample

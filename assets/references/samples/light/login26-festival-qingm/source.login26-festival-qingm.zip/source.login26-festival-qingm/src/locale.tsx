import React from 'react'
import BaseLoginForm, { IAllLangs } from '@elem/login-base'
import { prefixCls } from './constants'
import { IProps } from './props'

export default class Locale extends BaseLoginForm<IProps> {
  static defaultProps = {
    moreLan: true
  };

  constructor (props: IProps) {
    super(props)
  }

  onChange = (val) => {
    this.changeLocale(val)
  };
  getAllLocales () {
    return mk.getUserConfig('allLocales') as IAllLangs
  }

  render () {
    const allLangs: IAllLangs = this.getAllLocales()
    const { moreLan } = this.props
    return (
      moreLan &&
      allLangs.length > 1 && (
        <div className={`${prefixCls}-topbar font-sm`}>
          {allLangs.length &&
            allLangs.map(lang => (
              <span
                className={`${prefixCls}-topbar-text`}
                key={lang.val}
                onClick={() => this.onChange(lang.val)}
              >
                {lang.name}
              </span>
            ))}
        </div>
      )
    )
  }
}

import React from 'react'
import Flex from '@elem/flex'
import Login from './login'
import Locale from './locale'
import Footer from './footer'
import { prefixCls } from './constants'
import { IProps as IBaseProps } from './props'
import './style.scss'

export interface IProps extends IBaseProps {}

const LoginLayout: React.FC<IProps> = (props) => {
  const { loginTitleDesc } = props
  console.log('propspropsprops =>>', props, loginTitleDesc)
  return (
    <Flex className={prefixCls} style={{backgroundImage: mk.getResourcePath(props.backgroundURL)}}>
      <Flex className={`${prefixCls}-flex-item`} bgColor="rgba(0,0,0,0.5)" style={{
        right: props.loginLocation === 'left' ? 'auto' : '0px',
        left: props.loginLocation === 'left' ? '0px' : 'auto'
      }}>
        <Locale {...props}/>
        <Login {...props}/>
        <Footer {...props}/>
      </Flex>
    </Flex>
  )
}

export default LoginLayout